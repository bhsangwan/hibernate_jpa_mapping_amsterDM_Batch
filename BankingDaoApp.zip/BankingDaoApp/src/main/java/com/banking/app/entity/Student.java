package com.banking.app.entity;

public class Student {
	private int stId;
	private String stName;
	private Address address;

}
