package com.banking.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.banking.app.entity.Account;
import com.banking.app.util.EMUtils;

public class AccountDaoImpl implements AccountDao {

	@Override
	public boolean createAccount(Account account) {
		boolean accountCreated = false;
		EntityManager em = EMUtils.provideEntityManager();
		em.getTransaction().begin();
		em.persist(account);
		accountCreated = true;
		System.out.println("Account created..!");
		em.getTransaction().commit();
		em.close();
		return accountCreated;
	}

	@Override
	public boolean deleteAccount(int accno) {
		boolean accountDeleted = false;
		EntityManager em = EMUtils.provideEntityManager();
		Account account = em.find(Account.class, accno);
		if (account != null) {
			em.getTransaction().begin();
			em.remove(account);
			accountDeleted = true;
			System.out.println("Account Deleted..!");
			em.getTransaction().commit();
			em.close();
		}else {
			System.out.println("Account not found..!");
		}
		return accountDeleted;
	}

	@Override
	public boolean updateAccount(Account account) {
		boolean accountUpdated = false;
		EntityManager em = EMUtils.provideEntityManager();
		em.getTransaction().begin();
		em.merge(account);
		accountUpdated = true;
		System.out.println("Account created..!");
		em.getTransaction().commit();
		em.close();
		return accountUpdated;
	}

	@Override
	public Account findAccountById(int accno) {
		
		return EMUtils.provideEntityManager().find(Account.class, accno);
	}
	
	public Account findAccountByName(String name) {
		EntityManager em = EMUtils.provideEntityManager();
		//Query query = em.createQuery("from Account where name='"+name+"'");
		//Account account = (Account)query.getSingleResult();
		String jpql = "from Account where name='"+name+"'";
		TypedQuery<Account> query = em.createQuery(jpql, Account.class);
		return query.getSingleResult();
	}
	
	@Override
	public List<Account> findAll(){
		EntityManager em = EMUtils.provideEntityManager();
		//String jpql = "from Account";
		String sql = "select * from account";
		Query query = em.createNativeQuery(sql, Account.class);
		List<Account> accounts = query.getResultList();
		return accounts;
	}

}
