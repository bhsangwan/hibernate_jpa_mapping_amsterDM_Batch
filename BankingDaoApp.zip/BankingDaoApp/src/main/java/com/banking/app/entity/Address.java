package com.banking.app.entity;

public class Address {

	private int addrId;
	private String city;
	private String state;
	private int pin;
	
}
