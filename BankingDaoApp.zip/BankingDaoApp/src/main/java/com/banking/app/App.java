package com.banking.app;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.banking.app.dao.AccountDao;
import com.banking.app.dao.AccountDaoImpl;
import com.banking.app.entity.Account;
import com.banking.app.entity.Department;
import com.banking.app.entity.Employee;
import com.banking.app.util.EMUtils;

public class App {

	public static void main(String[] args) {
		
		/*EntityManager em = EMUtils.provideEntityManager();
		
		Department dept=new Department();
		dept.setDname("Sales");
		dept.setDlocation("mumbai");
		
		Employee emp1=new Employee();
		emp1.setName("ram");
		emp1.setSalary(7800);
		emp1.setDept(dept);
		
		Employee emp2=new Employee();
		emp2.setName("ramesh");
		emp2.setSalary(8850);
		emp2.setDept(dept);
		
		em.getTransaction().begin();
		
		em.persist(emp1);
		em.persist(emp2);
		
		em.getTransaction().commit();
		
		System.out.println("done...");
		*/
		//Code for getiing all employees from particular Department
		//How to do this using native sql?????
		/*String jpql= "select emps from Department where dname='HR'";
		
		Query q= em.createQuery(jpql);
		
		List<Employee> allemps= q.getResultList();
		
		em.close();
		
		System.out.println(allemps);
		
		
		System.out.println("done...");
		*/
		//Code for adding employee in available dept
		
		/*Department dept = em.find(Department.class, 3);
		
		Employee emp1 = new Employee(0, "Rahul", 8000);
		
		em.getTransaction().begin();
		
			dept.getEmps().add(emp1);
		
		em.getTransaction().commit();
		em.close();*/
		
		//Code for creating Department and employees 
		
		/*Employee emp1 = new Employee(0, "Sachin", 12000);
		Employee emp2 = new Employee(0, "Dimple", 13000);
		
		Department dept = new Department();
		dept.setDname("HR");
		dept.setDlocation("PUNE");
		
		dept.getEmps().add(emp1);
		dept.getEmps().add(emp2);
		
		
		
		em.getTransaction().begin();
		
		em.persist(emp1);
		em.persist(emp2);
		em.persist(dept);
		
		em.getTransaction().commit();
		em.close();
		System.out.println("Done..!");*/
		
		
	}

}
